<?php
namespace ramirkz\kozdonate;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin-owned aggregate tables require direct queries for atomic counters and reports.
 */
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange

final class KOZDONATE_Storage {
	public const DB_VERSION = '1.2.0';
	public const DAILY_SUFFIX = 'kozdonate_daily';
	public const SESSIONS_SUFFIX = 'kozdonate_sessions';
	public const CONFIRMATIONS_SUFFIX = 'kozdonate_confirmations';

	private static string $daily_table = '';
	private static string $sessions_table = '';
	private static string $confirmations_table = '';

	private static function legacy_suffix( string $kind ): string {
		return implode( '', array( 'ua', 'free' ) ) . '_donate_' . $kind;
	}

	private static function table_exists( string $table ): bool {
		global $wpdb;
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		return $table === $found;
	}

	private static function migrate_legacy_tables(): void {
		global $wpdb;

		if ( false !== get_option( 'kozdonate_legacy_tables_migrated_138', false ) ) {
			return;
		}

		$legacy_daily = $wpdb->prefix . self::legacy_suffix( 'daily' );
		$legacy_sessions = $wpdb->prefix . self::legacy_suffix( 'sessions' );
		$legacy_confirmations = $wpdb->prefix . self::legacy_suffix( 'confirmations' );
		$ok = true;

		if ( self::table_exists( $legacy_daily ) ) {
			$ok = false !== $wpdb->query(
				$wpdb->prepare(
					'INSERT INTO %i (stat_date,language,context_key,event_type,target_key,event_count,created_at,updated_at)
					 SELECT stat_date,language,context_key,event_type,target_key,event_count,created_at,updated_at FROM %i
					 ON DUPLICATE KEY UPDATE event_count=event_count+VALUES(event_count), created_at=LEAST(created_at,VALUES(created_at)), updated_at=GREATEST(updated_at,VALUES(updated_at))',
					self::$daily_table,
					$legacy_daily
				)
			) && $ok;
		}

		if ( self::table_exists( $legacy_sessions ) ) {
			$ok = false !== $wpdb->query(
				$wpdb->prepare(
					'INSERT IGNORE INTO %i (stat_date,language,context_key,session_hash,created_at)
					 SELECT stat_date,language,context_key,session_hash,created_at FROM %i',
					self::$sessions_table,
					$legacy_sessions
				)
			) && $ok;
		}

		if ( self::table_exists( $legacy_confirmations ) ) {
			$ok = false !== $wpdb->query(
				$wpdb->prepare(
					'INSERT IGNORE INTO %i (reference_hash,provider,language,context_key,created_at)
					 SELECT reference_hash,provider,language,context_key,created_at FROM %i',
					self::$confirmations_table,
					$legacy_confirmations
				)
			) && $ok;
		}

		if ( $ok ) {
			update_option( 'kozdonate_legacy_tables_migrated_138', 1, false );
		}
	}


	public static function init(): void {
		global $wpdb;
		self::$daily_table = $wpdb->prefix . self::DAILY_SUFFIX;
		self::$sessions_table = $wpdb->prefix . self::SESSIONS_SUFFIX;
		self::$confirmations_table = $wpdb->prefix . self::CONFIRMATIONS_SUFFIX;
	}

	public static function daily_table(): string {
		self::ensure_initialized();
		return self::$daily_table;
	}

	public static function sessions_table(): string {
		self::ensure_initialized();
		return self::$sessions_table;
	}

	private static function ensure_initialized(): void {
		if ( '' === self::$daily_table || '' === self::$sessions_table || '' === self::$confirmations_table ) {
			self::init();
		}
	}

	public static function install_schema(): void {
		global $wpdb;
		self::init();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$daily_sql = "CREATE TABLE " . self::$daily_table . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			stat_date date NOT NULL,
			language varchar(16) NOT NULL DEFAULT 'und',
			context_key varchar(100) NOT NULL DEFAULT 'legacy',
			event_type varchar(32) NOT NULL DEFAULT '',
			target_key varchar(100) NOT NULL DEFAULT '',
			event_count bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY event_bucket_v2 (stat_date,language,context_key,event_type,target_key),
			KEY stat_date (stat_date),
			KEY event_type (event_type),
			KEY context_key (context_key)
		) {$charset};";

		$sessions_sql = "CREATE TABLE " . self::$sessions_table . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			stat_date date NOT NULL,
			language varchar(16) NOT NULL DEFAULT 'und',
			context_key varchar(100) NOT NULL DEFAULT 'legacy',
			session_hash char(64) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY daily_language_context_session (stat_date,language,context_key,session_hash),
			KEY stat_date (stat_date),
			KEY context_key (context_key),
			KEY session_hash (session_hash)
		) {$charset};";

		$confirmations_sql = "CREATE TABLE " . self::$confirmations_table . " (
			reference_hash char(64) NOT NULL,
			provider varchar(40) NOT NULL DEFAULT 'payment',
			language varchar(16) NOT NULL DEFAULT 'und',
			context_key varchar(100) NOT NULL DEFAULT 'confirmed-donation',
			amount decimal(14,2) DEFAULT NULL,
			currency char(3) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (reference_hash),
			KEY created_at (created_at),
			KEY provider (provider)
		) {$charset};";

		dbDelta( $daily_sql );
		dbDelta( $sessions_sql );
		dbDelta( $confirmations_sql );

		self::remove_obsolete_indexes();
		self::ensure_v2_indexes();
		self::migrate_legacy_tables();

		update_option( 'kozdonate_db_version', self::DB_VERSION, false );
	}

	private static function remove_obsolete_indexes(): void {
		global $wpdb;

		$daily_indexes = self::index_names( self::$daily_table );
		if ( in_array( 'event_bucket', $daily_indexes, true ) ) {
			$wpdb->query( $wpdb->prepare( 'ALTER TABLE %i DROP INDEX `event_bucket`', self::$daily_table ) );
		}

		$session_indexes = self::index_names( self::$sessions_table );
		if ( in_array( 'daily_language_session', $session_indexes, true ) ) {
			$wpdb->query( $wpdb->prepare( 'ALTER TABLE %i DROP INDEX `daily_language_session`', self::$sessions_table ) );
		}
	}

	private static function ensure_v2_indexes(): void {
		global $wpdb;

		$daily_indexes = self::index_names( self::$daily_table );
		if ( ! in_array( 'event_bucket_v2', $daily_indexes, true ) ) {
			$wpdb->query(
				$wpdb->prepare(
					'ALTER TABLE %i ADD UNIQUE KEY `event_bucket_v2` (`stat_date`,`language`,`context_key`,`event_type`,`target_key`)',
					self::$daily_table
				)
			);
		}

		$session_indexes = self::index_names( self::$sessions_table );
		if ( ! in_array( 'daily_language_context_session', $session_indexes, true ) ) {
			$wpdb->query(
				$wpdb->prepare(
					'ALTER TABLE %i ADD UNIQUE KEY `daily_language_context_session` (`stat_date`,`language`,`context_key`,`session_hash`)',
					self::$sessions_table
				)
			);
		}
	}

	/**
	 * @return array<int,string>
	 */
	private static function index_names( string $table ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SHOW INDEX FROM %i', $table ), ARRAY_A );
		$names = array();

		foreach ( (array) $rows as $row ) {
			if ( isset( $row['Key_name'] ) ) {
				$names[] = (string) $row['Key_name'];
			}
		}

		return array_values( array_unique( $names ) );
	}

	public static function increment_event(
		string $language,
		string $context_key,
		string $event_type,
		string $target_key
	): bool {
		global $wpdb;
		self::ensure_initialized();

		$now = current_time( 'mysql', true );
		$result = $wpdb->query(
			$wpdb->prepare(
				"INSERT INTO %i
				(stat_date, language, context_key, event_type, target_key, event_count, created_at, updated_at)
				VALUES (%s, %s, %s, %s, %s, 1, %s, %s)
				ON DUPLICATE KEY UPDATE
					event_count = event_count + 1,
					updated_at = VALUES(updated_at)",
				self::$daily_table,
				current_time( 'Y-m-d' ),
				$language,
				$context_key,
				$event_type,
				$target_key,
				$now,
				$now
			)
		);

		return false !== $result;
	}

	public static function store_session(
		string $language,
		string $context_key,
		string $session_hash
	): bool {
		global $wpdb;
		self::ensure_initialized();

		$result = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO %i
				(stat_date, language, context_key, session_hash, created_at)
				VALUES (%s, %s, %s, %s, %s)",
				self::$sessions_table,
				current_time( 'Y-m-d' ),
				$language,
				$context_key,
				$session_hash,
				current_time( 'mysql', true )
			)
		);

		return false !== $result;
	}


	/**
	 * Record one unique server-confirmed donation.
	 *
	 * The raw provider reference is never stored. Only its HMAC hash is kept
	 * to prevent the same callback from increasing the total twice.
	 *
	 * @return string recorded|duplicate|error
	 */
	public static function record_confirmation(
		string $reference_hash,
		string $provider,
		string $language,
		string $context_key,
		?float $amount = null,
		string $currency = ''
	): string {
		global $wpdb;
		self::ensure_initialized();

		if ( 1 !== preg_match( '/^[a-f0-9]{64}$/', $reference_hash ) ) {
			return 'error';
		}

		// Amounts are kept only when the administrator turned on "Store donation amounts".
		$store_amount = ! empty( KOZDONATE_Plugin::settings()['store_amounts'] ) && null !== $amount && $amount > 0;
		$currency     = $store_amount && preg_match( '/^[A-Z]{3}$/', strtoupper( $currency ) ) ? strtoupper( $currency ) : '';

		if ( $store_amount ) {
			$result = $wpdb->query(
				$wpdb->prepare(
					"INSERT IGNORE INTO %i
					(reference_hash, provider, language, context_key, amount, currency, created_at)
					VALUES (%s, %s, %s, %s, %f, %s, %s)",
					self::$confirmations_table,
					$reference_hash,
					$provider,
					$language,
					$context_key,
					round( (float) $amount, 2 ),
					$currency,
					current_time( 'mysql', true )
				)
			);
		} else {
			$result = $wpdb->query(
				$wpdb->prepare(
					"INSERT IGNORE INTO %i
					(reference_hash, provider, language, context_key, created_at)
					VALUES (%s, %s, %s, %s, %s)",
					self::$confirmations_table,
					$reference_hash,
					$provider,
					$language,
					$context_key,
					current_time( 'mysql', true )
				)
			);
		}

		if ( false === $result ) {
			return 'error';
		}
		if ( 0 === (int) $result ) {
			return 'duplicate';
		}

		$accepted = self::increment_event(
			$language,
			$context_key,
			'donation_success',
			$provider
		);
		if ( ! $accepted ) {
			$wpdb->delete(
				self::$confirmations_table,
				array( 'reference_hash' => $reference_hash ),
				array( '%s' )
			);
			return 'error';
		}

		update_option(
			KOZDONATE_Plugin::LAST_CONFIRMATION_OPTION,
			current_time( 'mysql', true ),
			false
		);
		return 'recorded';
	}

	public static function cleanup_old_data( int $retention_days ): void {
		global $wpdb;
		self::ensure_initialized();

		$retention_days = max( 30, min( 730, $retention_days ) );
		$cutoff = gmdate( 'Y-m-d', time() - ( $retention_days * DAY_IN_SECONDS ) );

		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE stat_date < %s',
				self::$daily_table,
				$cutoff
			)
		);
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE stat_date < %s',
				self::$sessions_table,
				$cutoff
			)
		);
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE created_at < %s',
				self::$confirmations_table,
				$cutoff . ' 00:00:00'
			)
		);
	}

	public static function reset(): void {
		global $wpdb;
		self::ensure_initialized();
		$wpdb->query( $wpdb->prepare( 'TRUNCATE TABLE %i', self::$daily_table ) );
		$wpdb->query( $wpdb->prepare( 'TRUNCATE TABLE %i', self::$sessions_table ) );
		$wpdb->query( $wpdb->prepare( 'TRUNCATE TABLE %i', self::$confirmations_table ) );
		delete_option( KOZDONATE_Plugin::LAST_CONFIRMATION_OPTION );
	}

	private static function date_cutoff( int $days ): string {
		$days = max( 1, min( 730, $days ) );
		return gmdate( 'Y-m-d', time() - ( max( 1, $days - 1 ) * DAY_IN_SECONDS ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function summary( int $days = 30 ): array {
		global $wpdb;
		self::ensure_initialized();

		$cutoff = self::date_cutoff( $days );
		$events = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT event_type, SUM(event_count) AS total
				FROM %i
				WHERE stat_date >= %s
				GROUP BY event_type",
				self::$daily_table,
				$cutoff
			),
			ARRAY_A
		);

		$map = array();
		foreach ( (array) $events as $row ) {
			$map[ (string) $row['event_type'] ] = (int) $row['total'];
		}

		$sessions = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT CONCAT(stat_date, ':', context_key, ':', session_hash))
				FROM %i
				WHERE stat_date >= %s",
				self::$sessions_table,
				$cutoff
			)
		);

		$payment_opens = (int) ( $map['payment_open'] ?? 0 )
			+ (int) ( $map['external_click'] ?? 0 );
		$successes = (int) ( $map['donation_success'] ?? 0 );

		$result = array(
			'days'             => max( 1, min( 730, $days ) ),
			'views'            => (int) ( $map['page_view'] ?? 0 ),
			'sessions'         => $sessions,
			'donate_clicks'    => (int) ( $map['donate_click'] ?? 0 ),
			'payment_opens'    => $payment_opens,
			'copy_clicks'      => (int) ( $map['copy_click'] ?? 0 ),
			'successes'         => $successes,
			'donations_total'   => $successes,
			'conversions_total' => $successes,
			'engagements'       => (int) ( $map['donate_click'] ?? 0 ) + $payment_opens + (int) ( $map['copy_click'] ?? 0 ),
			'conversion_rate'   => $sessions > 0 ? ( $successes / $sessions ) * 100 : 0.0,
			'events_by_type'    => $map,
		);

		return apply_filters( 'kozdonate_summary', $result, $days );
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public static function daily_rows( int $days = 30 ): array {
		global $wpdb;
		self::ensure_initialized();

		$cutoff = self::date_cutoff( $days );
		$events = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					stat_date,
					SUM(CASE WHEN event_type = 'page_view' THEN event_count ELSE 0 END) AS views,
					SUM(CASE WHEN event_type = 'donate_click' THEN event_count ELSE 0 END) AS donate_clicks,
					SUM(CASE WHEN event_type IN ('payment_open','external_click') THEN event_count ELSE 0 END) AS payment_opens,
					SUM(CASE WHEN event_type = 'copy_click' THEN event_count ELSE 0 END) AS copy_clicks,
					SUM(CASE WHEN event_type = 'donation_success' THEN event_count ELSE 0 END) AS successes
				FROM %i
				WHERE stat_date >= %s
				GROUP BY stat_date
				ORDER BY stat_date DESC",
				self::$daily_table,
				$cutoff
			),
			ARRAY_A
		);

		$sessions = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT stat_date, COUNT(DISTINCT CONCAT(context_key, ':', session_hash)) AS sessions
				FROM %i
				WHERE stat_date >= %s
				GROUP BY stat_date",
				self::$sessions_table,
				$cutoff
			),
			OBJECT_K
		);

		$result = array();
		foreach ( (array) $events as $row ) {
			$date = (string) $row['stat_date'];
			$result[] = array(
				'stat_date'     => $date,
				'views'         => (int) $row['views'],
				'sessions'      => isset( $sessions[ $date ] ) ? (int) $sessions[ $date ]->sessions : 0,
				'donate_clicks' => (int) $row['donate_clicks'],
				'payment_opens' => (int) $row['payment_opens'],
				'copy_clicks'   => (int) $row['copy_clicks'],
				'successes'     => (int) $row['successes'],
			);
		}
		return $result;
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public static function top_targets( int $days = 30 ): array {
		global $wpdb;
		self::ensure_initialized();

		return (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT event_type, target_key, SUM(event_count) AS event_count
				FROM %i
				WHERE stat_date >= %s
					AND event_type IN ('donate_click','payment_open','external_click','copy_click','donation_success')
				GROUP BY event_type, target_key
				ORDER BY event_count DESC
				LIMIT 50",
				self::$daily_table,
				self::date_cutoff( $days )
			),
			ARRAY_A
		);
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public static function context_rows( int $days = 30 ): array {
		global $wpdb;
		self::ensure_initialized();

		$cutoff = self::date_cutoff( $days );
		$events = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					context_key,
					SUM(CASE WHEN event_type = 'page_view' THEN event_count ELSE 0 END) AS views,
					SUM(CASE WHEN event_type IN ('donate_click','payment_open','external_click','copy_click') THEN event_count ELSE 0 END) AS engagements,
					SUM(CASE WHEN event_type = 'donation_success' THEN event_count ELSE 0 END) AS successes
				FROM %i
				WHERE stat_date >= %s
				GROUP BY context_key",
				self::$daily_table,
				$cutoff
			),
			OBJECT_K
		);

		$sessions = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT context_key, COUNT(DISTINCT CONCAT(stat_date, ':', session_hash)) AS sessions
				FROM %i
				WHERE stat_date >= %s
				GROUP BY context_key",
				self::$sessions_table,
				$cutoff
			),
			OBJECT_K
		);

		$keys = array_unique( array_merge( array_keys( (array) $events ), array_keys( (array) $sessions ) ) );
		$result = array();
		foreach ( $keys as $key ) {
			$session_count = isset( $sessions[ $key ] ) ? (int) $sessions[ $key ]->sessions : 0;
			$successes = isset( $events[ $key ] ) ? (int) $events[ $key ]->successes : 0;
			$result[] = array(
				'context_key'    => $key,
				'views'          => isset( $events[ $key ] ) ? (int) $events[ $key ]->views : 0,
				'sessions'       => $session_count,
				'engagements'    => isset( $events[ $key ] ) ? (int) $events[ $key ]->engagements : 0,
				'successes'      => $successes,
				'conversion_rate'=> $session_count > 0 ? ( $successes / $session_count ) * 100 : 0.0,
			);
		}
		usort(
			$result,
			static fn( array $a, array $b ): int =>
				( $b['views'] + $b['engagements'] ) <=> ( $a['views'] + $a['engagements'] )
		);
		return $result;
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public static function language_rows( int $days = 30 ): array {
		global $wpdb;
		self::ensure_initialized();

		$cutoff = self::date_cutoff( $days );
		$events = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					language,
					SUM(CASE WHEN event_type = 'page_view' THEN event_count ELSE 0 END) AS views,
					SUM(CASE WHEN event_type IN ('donate_click','payment_open','external_click','copy_click') THEN event_count ELSE 0 END) AS engagements,
					SUM(CASE WHEN event_type = 'donation_success' THEN event_count ELSE 0 END) AS successes
				FROM %i
				WHERE stat_date >= %s
				GROUP BY language",
				self::$daily_table,
				$cutoff
			),
			OBJECT_K
		);

		$sessions = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT language, COUNT(DISTINCT CONCAT(stat_date, ':', context_key, ':', session_hash)) AS sessions
				FROM %i
				WHERE stat_date >= %s
				GROUP BY language",
				self::$sessions_table,
				$cutoff
			),
			OBJECT_K
		);

		$languages = array_unique( array_merge( array_keys( (array) $events ), array_keys( (array) $sessions ) ) );
		$result = array();
		foreach ( $languages as $language ) {
			$result[] = array(
				'language'    => $language,
				'views'       => isset( $events[ $language ] ) ? (int) $events[ $language ]->views : 0,
				'sessions'    => isset( $sessions[ $language ] ) ? (int) $sessions[ $language ]->sessions : 0,
				'engagements' => isset( $events[ $language ] ) ? (int) $events[ $language ]->engagements : 0,
				'successes'   => isset( $events[ $language ] ) ? (int) $events[ $language ]->successes : 0,
			);
		}
		usort(
			$result,
			static fn( array $a, array $b ): int =>
				( $b['views'] + $b['engagements'] ) <=> ( $a['views'] + $a['engagements'] )
		);
		return $result;
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function export_payload( int $days = 30 ): array {
		return array(
			'generated_at_utc' => gmdate( 'c' ),
			'period_days'      => max( 1, min( 730, $days ) ),
			'privacy'          => array(
				'contains_ip_addresses'  => false,
				'contains_user_agents'   => false,
				'contains_referrers'     => false,
				'contains_payment_data'  => false,
				'contains_personal_data' => false,
			),
			'summary'          => self::summary( $days ),
			'daily'            => self::daily_rows( $days ),
			'contexts'         => self::context_rows( $days ),
			'languages'        => self::language_rows( $days ),
			'targets'          => self::top_targets( $days ),
		);
	}

	/**
	 * Funnel totals for a window that ended $offset days ago (0 = the current period).
	 *
	 * @return array{views:int,sessions:int,donate_clicks:int,payment_opens:int,successes:int}
	 */
	public static function period_totals( int $days, int $offset = 0 ): array {
		global $wpdb;
		self::ensure_initialized();
		$days  = max( 1, min( 730, $days ) );
		$end   = wp_date( 'Y-m-d', time() - $offset * DAY_IN_SECONDS );
		$start = wp_date( 'Y-m-d', time() - ( $offset + $days - 1 ) * DAY_IN_SECONDS );
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT
					SUM(CASE WHEN event_type = 'page_view' THEN event_count ELSE 0 END) AS views,
					SUM(CASE WHEN event_type = 'donate_click' THEN event_count ELSE 0 END) AS donate_clicks,
					SUM(CASE WHEN event_type IN ('payment_open','external_click') THEN event_count ELSE 0 END) AS payment_opens,
					SUM(CASE WHEN event_type = 'donation_success' THEN event_count ELSE 0 END) AS successes
				FROM %i WHERE stat_date BETWEEN %s AND %s",
				self::$daily_table,
				$start,
				$end
			),
			ARRAY_A
		);
		$sessions = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT CONCAT(stat_date, ':', context_key, ':', session_hash)) FROM %i WHERE stat_date BETWEEN %s AND %s",
				self::$sessions_table,
				$start,
				$end
			)
		);
		return array(
			'views'         => (int) ( $row['views'] ?? 0 ),
			'sessions'      => $sessions,
			'donate_clicks' => (int) ( $row['donate_clicks'] ?? 0 ),
			'payment_opens' => (int) ( $row['payment_opens'] ?? 0 ),
			'successes'     => (int) ( $row['successes'] ?? 0 ),
		);
	}

	/**
	 * Payment openings and confirmed donations by payment service.
	 *
	 * @return array<string,array{opens:int,successes:int}>
	 */
	public static function provider_rows( int $days = 30 ): array {
		global $wpdb;
		self::ensure_initialized();
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT event_type, target_key, SUM(event_count) AS total FROM %i
				WHERE stat_date >= %s AND event_type IN ('payment_open','external_click','donation_success')
				GROUP BY event_type, target_key",
				self::$daily_table,
				self::date_cutoff( $days )
			),
			ARRAY_A
		);
		$result = array();
		foreach ( (array) $rows as $row ) {
			$label = KOZDONATE_Plugin::provider_label( (string) $row['target_key'] );
			if ( ! isset( $result[ $label ] ) ) {
				$result[ $label ] = array( 'opens' => 0, 'successes' => 0 );
			}
			if ( 'donation_success' === $row['event_type'] ) {
				$result[ $label ]['successes'] += (int) $row['total'];
			} else {
				$result[ $label ]['opens'] += (int) $row['total'];
			}
		}
		uasort( $result, static fn( array $a, array $b ): int => ( $b['opens'] + $b['successes'] ) <=> ( $a['opens'] + $a['successes'] ) );
		return $result;
	}

	/**
	 * Confirmed amounts by currency (only rows stored while "Store donation amounts" was on).
	 *
	 * @return array<int,array{currency:string,total:float,count:int}>
	 */
	public static function amount_totals( int $days = 30 ): array {
		global $wpdb;
		self::ensure_initialized();
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT currency, SUM(amount) AS total, COUNT(*) AS donations FROM %i
				WHERE created_at >= %s AND amount IS NOT NULL AND currency <> ''
				GROUP BY currency ORDER BY total DESC",
				self::$confirmations_table,
				self::date_cutoff( $days ) . ' 00:00:00'
			),
			ARRAY_A
		);
		$result = array();
		foreach ( (array) $rows as $row ) {
			$result[] = array(
				'currency' => (string) $row['currency'],
				'total'    => (float) $row['total'],
				'count'    => (int) $row['donations'],
			);
		}
		return $result;
	}

	/** Removes stored amounts when the administrator turns the option off. */
	public static function forget_amounts(): void {
		global $wpdb;
		self::ensure_initialized();
		$wpdb->query( $wpdb->prepare( "UPDATE %i SET amount = NULL, currency = ''", self::$confirmations_table ) );
	}

	/** Events recorded in the last $days days, for the Site Health test. */
	public static function recent_event_count( int $days = 7 ): int {
		global $wpdb;
		self::ensure_initialized();
		return (int) $wpdb->get_var(
			$wpdb->prepare( 'SELECT SUM(event_count) FROM %i WHERE stat_date >= %s', self::$daily_table, self::date_cutoff( $days ) )
		);
	}

	public static function table_counts(): array {
		global $wpdb;
		self::ensure_initialized();
		return array(
			'daily_rows'        => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', self::$daily_table ) ),
			'session_rows'      => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', self::$sessions_table ) ),
			'confirmation_rows' => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', self::$confirmations_table ) ),
		);
	}
}

// phpcs:enable

KOZDONATE_Storage::init();
