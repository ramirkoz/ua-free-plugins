<?php
namespace ramirkz\kozdonate;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class KOZDONATE_Plugin {
	public const OPTION = 'kozdonate_settings';
	public const PAGE_SLUG = 'koz-donate-stats';
	public const CLEANUP_HOOK = 'kozdonate_cleanup';
	public const EXPORT_CSV_ACTION = 'kozdonate_export_csv';
	public const EXPORT_JSON_ACTION = 'kozdonate_export_json';
	public const RESET_ACTION = 'kozdonate_reset';
	public const ROTATE_SECRET_ACTION = 'kozdonate_rotate_secret';
	public const RESET_PHRASE = 'DELETE DONATION STATS';
	public const LAST_CONFIRMATION_OPTION = 'kozdonate_last_confirmation_at';
	public const SETTINGS_VERSION = 7;

	private static function legacy_prefix(): string {
		return implode( '', array( 'ua', 'free' ) );
	}

	private static function legacy_option_name(): string {
		return self::legacy_prefix() . '_donate_stats_settings';
	}

	private static function legacy_confirmation_option(): string {
		return self::legacy_prefix() . '_donate_stats_last_confirmation_at';
	}

	private static function legacy_cleanup_hook(): string {
		return self::legacy_prefix() . '_donate_stats_cleanup';
	}

	private static function maybe_migrate_legacy_options(): void {
		$legacy = get_option( self::legacy_option_name(), false );
		$current = get_option( self::OPTION, false );

		if ( is_array( $legacy ) && false === get_option( 'kozdonate_legacy_settings_migrated_138', false ) ) {
			$current_array = is_array( $current ) ? $current : array();
			// Historical administrator choices win; current-only fields are kept as fallback.
			$merged = wp_parse_args( $legacy, $current_array );
			update_option( self::OPTION, $merged, false );
			update_option( 'kozdonate_legacy_settings_migrated_138', 1, false );
		} elseif ( false === $current && is_array( $legacy ) ) {
			add_option( self::OPTION, $legacy, '', false );
		}

		if ( false === get_option( self::LAST_CONFIRMATION_OPTION, false ) ) {
			$legacy_confirmation = get_option( self::legacy_confirmation_option(), false );
			if ( false !== $legacy_confirmation ) {
				add_option( self::LAST_CONFIRMATION_OPTION, $legacy_confirmation, '', false );
			}
		}
	}


	private static function ensure_cleanup_schedule(): void {
		if ( ! wp_next_scheduled( self::CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_HOOK );
		}
	}

	public static function init(): void {
		self::maybe_migrate_legacy_options();
		self::ensure_cleanup_schedule();
		add_action( 'admin_init', array( __CLASS__, 'maybe_upgrade' ) );
		add_action( self::CLEANUP_HOOK, array( __CLASS__, 'cleanup_old_data' ) );
		add_filter( 'kozdonate_public_status', array( KOZDONATE_Tracker::class, 'public_status' ) );

		KOZDONATE_Tracker::init();
		KOZDONATE_Providers::init();
		KOZDONATE_Insights::init();
		KOZDONATE_Admin::init();
		add_action( 'update_option_' . self::OPTION, array( __CLASS__, 'settings_changed' ), 10, 2 );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function defaults(): array {
		return array(
			'settings_version'    => self::SETTINGS_VERSION,
			'enabled'             => 0,
			'retention_days'      => 90,
			'exclude_admins'      => 1,
			'session_minutes'     => 30,
			'tracked_page_ids'    => array(),
			'tracked_paths'       => array(),
			'include_static_translations' => 1,
			'copy_selector'       => '[data-kozdonate-copy], [data-uafree-copy], [class*="copy-this-"]',
			'donate_selector'     => '[data-kozdonate-donate], [data-uafree-donate]',
			'payment_selector'    => 'a[data-kozdonate-payment], a[data-uafree-payment], .uafree-payment-link',
			'success_selector'    => '[data-kozdonate-donation-success], [data-uafree-donation-success]',
			'payment_hosts'       => array(),
			'auto_payment_hosts'  => 1,
			'storage_consent'     => 1,
			'ga4_events'          => 0,
			'store_amounts'       => 0,
			'liqpay_enabled'      => 0,
			'liqpay_private_key'  => '',
			'paypal_enabled'      => 0,
			'paypal_receiver'     => '',
			'allow_client_success'=> 0,
			'confirmation_mode'   => 'webhook',
			'confirmation_secret' => '',
			'ad_account_mode'     => 'none',
			'data_layer_enabled'  => 0,
			'data_layer_event'    => 'kozdonate_donation_event',
			'consent_gate'        => 'external_only',
			'consent_category'    => 'analytics',
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function settings(): array {
		$current = get_option( self::OPTION, array() );
		$current = is_array( $current ) ? $current : array();
		$value = wp_parse_args( $current, self::defaults() );

		$value['tracked_page_ids'] = array_values(
			array_unique(
				array_filter(
					array_map( 'absint', (array) $value['tracked_page_ids'] )
				)
			)
		);
		$value['tracked_paths'] = array_values( array_filter( (array) $value['tracked_paths'], 'is_string' ) );
		$value['payment_hosts'] = array_values( array_filter( (array) $value['payment_hosts'], 'is_string' ) );
		$mode = sanitize_key( (string) ( $value['confirmation_mode'] ?? 'webhook' ) );
		$value['confirmation_mode'] = in_array( $mode, array( 'webhook', 'client_marker', 'none' ), true )
			? $mode
			: 'webhook';
		$secret = strtolower( trim( (string) ( $value['confirmation_secret'] ?? '' ) ) );
		if ( ! preg_match( '/^[a-f0-9]{64}$/', $secret ) ) {
			$secret = self::new_confirmation_secret();
			$value['confirmation_secret'] = $secret;
			update_option( self::OPTION, array_merge( $current, array( 'confirmation_secret' => $secret ) ), false );
		}

		return $value;
	}

	public static function activate(): void {
		self::maybe_migrate_legacy_options();
		KOZDONATE_Storage::install_schema();

		if ( false === get_option( self::OPTION, false ) ) {
			$defaults = self::defaults();
			$defaults['confirmation_secret'] = self::new_confirmation_secret();
			add_option( self::OPTION, $defaults, '', false );
		}

		if ( ! wp_next_scheduled( self::CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_HOOK );
		}

		self::maybe_upgrade();
	}

	public static function deactivate(): void {
		$timestamp = wp_next_scheduled( self::CLEANUP_HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::CLEANUP_HOOK );
		}
	}

	public static function maybe_upgrade(): void {
		if ( KOZDONATE_Storage::DB_VERSION !== (string) get_option( 'kozdonate_db_version', '' ) ) {
			KOZDONATE_Storage::install_schema();
		}

		$current = get_option( self::OPTION, array() );
		if ( false === $current ) {
			return;
		}
		$current = is_array( $current ) ? $current : array();

		$previous_settings_version = (int) ( $current['settings_version'] ?? 0 );
		if ( $previous_settings_version < self::SETTINGS_VERSION ) {
			wp_clear_scheduled_hook( self::legacy_cleanup_hook() );
		}

		if ( $previous_settings_version >= self::SETTINGS_VERSION ) {
			return;
		}

		$migrated = wp_parse_args( $current, self::defaults() );
		$migrated['settings_version'] = self::SETTINGS_VERSION;
		$migrated['liqpay_private_key_keep'] = (string) ( $current['liqpay_private_key'] ?? '' );

		/*
		 * The version 3 migration intentionally cleared site-specific routes.
		 * Later schema upgrades must preserve the administrator's selections.
		 */
		if ( $previous_settings_version < 3 ) {
			$migrated['tracked_page_ids'] = array();
			$migrated['tracked_paths'] = array();
			$migrated['data_layer_enabled'] = 0;
			$migrated['ad_account_mode'] = 'none';
			$migrated['confirmation_mode'] = 'webhook';
		}

		if ( empty( $migrated['confirmation_secret'] ) ) {
			$migrated['confirmation_secret'] = self::new_confirmation_secret();
		}

		update_option( self::OPTION, self::sanitize_settings( $migrated ), false );
	}

	/**
	 * @param mixed $input
	 * @return array<string,mixed>
	 */
	public static function sanitize_settings( $input ): array {
		$input = is_array( $input ) ? $input : array();
		$defaults = self::defaults();

		$page_ids = array_slice(
			array_values(
				array_unique(
					array_filter(
						array_map( 'absint', (array) ( $input['tracked_page_ids'] ?? array() ) )
					)
				)
			),
			0,
			100
		);

		$paths_raw = is_array( $input['tracked_paths'] ?? null )
			? implode( "\n", $input['tracked_paths'] )
			: (string) ( $input['tracked_paths'] ?? '' );
		$paths = self::sanitize_lines( $paths_raw, array( __CLASS__, 'sanitize_path_pattern' ), 100 );

		$hosts_raw = is_array( $input['payment_hosts'] ?? null )
			? implode( "\n", $input['payment_hosts'] )
			: (string) ( $input['payment_hosts'] ?? '' );
		$hosts = self::sanitize_lines( $hosts_raw, array( __CLASS__, 'sanitize_hostname' ), 100 );

		$ad_mode = sanitize_key( (string) ( $input['ad_account_mode'] ?? 'none' ) );
		if ( ! in_array( $ad_mode, array( 'none', 'ad_grants', 'google_ads' ), true ) ) {
			$ad_mode = 'none';
		}

		$consent_gate = sanitize_key( (string) ( $input['consent_gate'] ?? 'external_only' ) );
		if ( ! in_array( $consent_gate, array( 'none', 'external_only', 'all' ), true ) ) {
			$consent_gate = 'external_only';
		}

		$data_layer_event = sanitize_key( (string) ( $input['data_layer_event'] ?? $defaults['data_layer_event'] ) );
		if ( '' === $data_layer_event ) {
			$data_layer_event = $defaults['data_layer_event'];
		}

		$confirmation_mode = sanitize_key( (string) ( $input['confirmation_mode'] ?? 'webhook' ) );
		if ( ! in_array( $confirmation_mode, array( 'webhook', 'client_marker', 'none' ), true ) ) {
			$confirmation_mode = 'webhook';
		}
		$current = get_option( self::OPTION, array() );
		$current = is_array( $current ) ? $current : array();
		$confirmation_secret = strtolower( trim( (string) ( $input['confirmation_secret'] ?? $current['confirmation_secret'] ?? '' ) ) );
		if ( ! preg_match( '/^[a-f0-9]{64}$/', $confirmation_secret ) ) {
			$confirmation_secret = self::new_confirmation_secret();
		}

		// The LiqPay private key is never printed back into the form: an empty field keeps it.
		$liqpay_key = trim( sanitize_text_field( (string) ( $input['liqpay_private_key'] ?? '' ) ) );
		if ( '' === $liqpay_key ) {
			$liqpay_key = (string) ( $input['liqpay_private_key_keep'] ?? $current['liqpay_private_key'] ?? '' );
		}
		if ( ! empty( $input['liqpay_private_key_clear'] ) ) {
			$liqpay_key = '';
		}
		$liqpay_key = substr( preg_replace( '/[^A-Za-z0-9_+=\/-]/', '', $liqpay_key ) ?? '', 0, 200 );
		$paypal_receiver = sanitize_email( (string) ( $input['paypal_receiver'] ?? '' ) );

		return array(
			'settings_version'     => self::SETTINGS_VERSION,
			'enabled'              => empty( $input['enabled'] ) ? 0 : 1,
			'retention_days'       => max( 30, min( 730, absint( $input['retention_days'] ?? 90 ) ) ),
			'exclude_admins'       => empty( $input['exclude_admins'] ) ? 0 : 1,
			'session_minutes'      => max( 5, min( 120, absint( $input['session_minutes'] ?? 30 ) ) ),
			'tracked_page_ids'     => $page_ids,
			'tracked_paths'        => $paths,
			'include_static_translations' => empty( $input['include_static_translations'] ) ? 0 : 1,
			'copy_selector'        => self::sanitize_selector( (string) ( $input['copy_selector'] ?? $defaults['copy_selector'] ), $defaults['copy_selector'] ),
			'donate_selector'      => self::sanitize_selector( (string) ( $input['donate_selector'] ?? $defaults['donate_selector'] ), $defaults['donate_selector'] ),
			'payment_selector'     => self::sanitize_selector( (string) ( $input['payment_selector'] ?? $defaults['payment_selector'] ), $defaults['payment_selector'] ),
			'success_selector'     => self::sanitize_selector( (string) ( $input['success_selector'] ?? $defaults['success_selector'] ), $defaults['success_selector'] ),
			'payment_hosts'        => $hosts,
			'allow_client_success' => 'client_marker' === $confirmation_mode && ! empty( $input['allow_client_success'] ) ? 1 : 0,
			'confirmation_mode'    => $confirmation_mode,
			'confirmation_secret'  => $confirmation_secret,
			'ad_account_mode'      => $ad_mode,
			'data_layer_enabled'   => empty( $input['data_layer_enabled'] ) ? 0 : 1,
			'data_layer_event'     => $data_layer_event,
			'consent_gate'         => $consent_gate,
			'consent_category'     => sanitize_key( (string) ( $input['consent_category'] ?? 'analytics' ) ) ?: 'analytics',
			'auto_payment_hosts'   => empty( $input['auto_payment_hosts'] ) ? 0 : 1,
			'storage_consent'      => empty( $input['storage_consent'] ) ? 0 : 1,
			'ga4_events'           => empty( $input['ga4_events'] ) ? 0 : 1,
			'store_amounts'        => empty( $input['store_amounts'] ) ? 0 : 1,
			'liqpay_enabled'       => empty( $input['liqpay_enabled'] ) ? 0 : 1,
			'liqpay_private_key'   => $liqpay_key,
			'paypal_enabled'       => empty( $input['paypal_enabled'] ) ? 0 : 1,
			'paypal_receiver'      => is_string( $paypal_receiver ) ? $paypal_receiver : '',
		);
	}



	/**
	 * Return active KOZ Static Translate language slugs.
	 *
	 * @return array<int,string>
	 */
	public static function static_translate_languages(): array {
		// KOZ Static Translate first; the former UA FREE function only as a fallback.
		$candidates = array( 'kozstx_get_status', implode( '_', array( 'uafree', 'static', 'translate', 'get', 'status' ) ) );
		$status     = null;
		foreach ( $candidates as $function ) {
			if ( ! is_callable( $function ) ) {
				continue;
			}
			try {
				$status = call_user_func( $function );
			} catch ( \Throwable $error ) {
				$status = null;
			}
			if ( is_array( $status ) ) {
				break;
			}
		}

		if ( ! is_array( $status ) || empty( $status['routes_enabled'] ) ) {
			return array();
		}

		$source = sanitize_key( (string) ( $status['source_language'] ?? '' ) );
		$languages = array();
		foreach ( (array) ( $status['target_languages'] ?? array() ) as $language ) {
			$slug = sanitize_key( (string) $language );
			if ( '' !== $slug && $slug !== $source && preg_match( '/^[a-z]{2,3}(?:-[a-z]{2})?$/', $slug ) ) {
				$languages[] = $slug;
			}
		}

		return array_values( array_unique( $languages ) );
	}

	/**
	 * Build translated frontend routes for selected source posts.
	 *
	 * @param array<int,int|string> $post_ids
	 * @return array<int,array{post_id:int,language:string,path:string,title:string}>
	 */
	public static function translated_routes( array $post_ids ): array {
		$languages = self::static_translate_languages();
		if ( empty( $languages ) ) {
			return array();
		}

		$home_path = self::normalize_local_path( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		$result = array();

		foreach ( array_values( array_unique( array_filter( array_map( 'absint', $post_ids ) ) ) ) as $post_id ) {
			$permalink = get_permalink( $post_id );
			if ( ! is_string( $permalink ) || '' === $permalink ) {
				continue;
			}

			$source_path = self::normalize_local_path( (string) wp_parse_url( $permalink, PHP_URL_PATH ) );
			$relative = ltrim( $source_path, '/' );
			if ( '/' !== $home_path && str_starts_with( $source_path, $home_path ) ) {
				$relative = ltrim( substr( $source_path, strlen( $home_path ) ), '/' );
			}

			$title = get_the_title( $post_id );
			$title = is_string( $title ) && '' !== $title ? $title : sprintf( 'Post %d', $post_id );

			foreach ( $languages as $language ) {
				$prefix = '/' === $home_path ? '/' : $home_path;
				$path = $prefix . $language . '/';
				if ( '' !== $relative ) {
					$path .= ltrim( $relative, '/' );
				}
				$path = self::normalize_local_path( $path );

				$result[] = array(
					'post_id'  => $post_id,
					'language' => $language,
					'path'     => $path,
					'title'    => $title,
				);
			}
		}

		return $result;
	}

	private static function normalize_local_path( string $path ): string {
		$path = '/' . ltrim( $path, '/' );
		$path = (string) preg_replace( '~/+~', '/', $path );
		return '/' === $path ? '/' : untrailingslashit( $path ) . '/';
	}

	/**
	 * Payment and donation services recognised without configuration.
	 *
	 * @return array<string,string> hostname => provider label
	 */
	public static function known_payment_hosts(): array {
		$hosts = array(
			'liqpay.ua'          => 'LiqPay',
			'send.monobank.ua'   => 'monobank',
			'monobank.ua'        => 'monobank',
			'pay.mbnk.biz'       => 'monobank',
			'paypal.com'         => 'PayPal',
			'paypal.me'          => 'PayPal',
			'secure.wayforpay.com' => 'WayForPay',
			'wayforpay.com'      => 'WayForPay',
			'pay.fondy.eu'       => 'Fondy',
			'fondy.ua'           => 'Fondy',
			'next.privat24.ua'   => 'Privat24',
			'privat24.ua'        => 'Privat24',
			'checkout.stripe.com' => 'Stripe',
			'buy.stripe.com'     => 'Stripe',
			'donate.stripe.com'  => 'Stripe',
			'buymeacoffee.com'   => 'Buy Me a Coffee',
			'ko-fi.com'          => 'Ko-fi',
			'patreon.com'        => 'Patreon',
			'opencollective.com' => 'Open Collective',
			'donorbox.org'       => 'Donorbox',
		);
		$filtered = apply_filters( 'kozdonate_known_payment_hosts', $hosts );
		return is_array( $filtered ) ? $filtered : $hosts;
	}

	/** Provider label for a stored target key (hostname or element id). */
	public static function provider_label( string $target ): string {
		$target = strtolower( $target );
		foreach ( self::known_payment_hosts() as $host => $label ) {
			if ( $target === $host || str_ends_with( $target, '.' . $host ) ) {
				return $label;
			}
		}
		foreach ( array( 'liqpay' => 'LiqPay', 'monobank' => 'monobank', 'mono' => 'monobank', 'paypal' => 'PayPal', 'wayforpay' => 'WayForPay', 'privat' => 'Privat24', 'stripe' => 'Stripe' ) as $needle => $label ) {
			if ( str_contains( $target, $needle ) ) {
				return $label;
			}
		}
		return '' !== $target ? $target : __( 'Other', 'koz-donate-stats' );
	}

	public static function new_confirmation_secret(): string {
		try {
			return bin2hex( random_bytes( 32 ) );
		} catch ( \Throwable $error ) {
			return hash( 'sha256', wp_generate_password( 64, true, true ) . wp_salt( 'auth' ) );
		}
	}

	public static function rotate_confirmation_secret(): string {
		$settings = self::settings();
		$settings['confirmation_secret'] = self::new_confirmation_secret();
		update_option( self::OPTION, $settings, false );
		return (string) $settings['confirmation_secret'];
	}

	public static function confirmation_callback_url(): string {
		return rest_url( KOZDONATE_Tracker::REST_NAMESPACE . '/confirm' );
	}

	/** @return array<string,mixed> */
	public static function confirmation_status(): array {
		$settings = self::settings();
		$mode = (string) $settings['confirmation_mode'];
		$secret = (string) $settings['confirmation_secret'];
		return array(
			'mode' => $mode,
			'ready' => 'webhook' === $mode && 1 === preg_match( '/^[a-f0-9]{64}$/', $secret ),
			'client_marker_enabled' => ! empty( $settings['allow_client_success'] ),
			'last_confirmation_at' => sanitize_text_field(
				(string) get_option( self::LAST_CONFIRMATION_OPTION, '' )
			),
		);
	}

	/**
	 * @return array<int,string>
	 */
	private static function sanitize_lines( string $raw, callable $callback, int $limit ): array {
		$parts = preg_split( '/[\r\n,]+/', wp_unslash( $raw ) );
		$result = array();
		foreach ( (array) $parts as $part ) {
			$value = call_user_func( $callback, trim( (string) $part ) );
			if ( '' !== $value ) {
				$result[] = $value;
			}
		}
		return array_slice( array_values( array_unique( $result ) ), 0, $limit );
	}

	private static function sanitize_path_pattern( string $value ): string {
		if ( '' === $value || str_contains( $value, '://' ) || str_contains( $value, '?' ) || str_contains( $value, '#' ) ) {
			return '';
		}
		$value = '/' . ltrim( sanitize_text_field( $value ), '/' );
		$value = preg_replace( '~/+~', '/', $value );
		$value = preg_replace( '~[^A-Za-z0-9_\-./*%]~', '', (string) $value );
		if ( strlen( $value ) > 200 ) {
			return '';
		}
		return '/' === $value ? '/' : untrailingslashit( $value ) . '/';
	}

	private static function sanitize_hostname( string $value ): string {
		$value = strtolower( trim( $value ) );
		$value = (string) preg_replace( '~^https?://~', '', $value );
		$value = explode( '/', $value, 2 )[0];
		$value = preg_replace( '/^www\./', '', $value );
		if ( ! preg_match( '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/', (string) $value ) ) {
			return '';
		}
		return substr( (string) $value, 0, 253 );
	}

	private static function sanitize_selector( string $value, string $fallback ): string {
		$value = sanitize_text_field( wp_unslash( $value ) );
		$value = preg_replace( '/[\x00-\x1F\x7F{}<>]/u', '', $value );
		$value = trim( substr( (string) $value, 0, 400 ) );
		return '' !== $value ? $value : $fallback;
	}

	/** Turning "Store donation amounts" off deletes the stored amounts. */
	public static function settings_changed( $old, $new ): void {
		if ( is_array( $old ) && is_array( $new ) && ! empty( $old['store_amounts'] ) && empty( $new['store_amounts'] ) ) {
			KOZDONATE_Storage::forget_amounts();
		}
	}

	public static function cleanup_old_data(): void {
		KOZDONATE_Storage::cleanup_old_data( (int) self::settings()['retention_days'] );
	}
}
