KOZ SITE BRIDGE 0.5.7 — WORDPRESS.ORG DIRECTORY ASSETS

Ready-to-use files:
  banner-1544x500.png  — 1544 x 500 px (retina)
  banner-772x250.png   — 772 x 250 px (standard)
  icon-256x256.png     — 256 x 256 px (retina)
  icon-128x128.png     — 128 x 128 px (standard)

COPY ALL 4 FILES TO:
  C:\KOZ-SVN\koz-site-bridge\assets\

Important: These are listing assets for the SVN root /assets directory,
NOT for trunk/assets, NOT for tags/0.5.7/assets.
Right click the root assets folder > SVN Commit; select all four files.
Suggested commit message:
  Add KOZ Site Bridge branded banner and icon assets

No screenshots are included: screenshots should be actual plugin UI, not invented.
Artwork is styled to match the other KOZ plugin directory banners.
The banner describes the real read-only diagnostics API, not site migration.
