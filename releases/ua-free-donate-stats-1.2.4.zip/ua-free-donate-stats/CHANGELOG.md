# Changelog

## 1.2.4

- Final repository and WordPress.org packaging release.
- Updated version, readme metadata, compatibility fields and license headers.
- No custom update checker or UA FREE usage telemetry added.

## 1.2.1

- Added a signed privacy-safe `/confirm` REST callback.
- Added idempotency table storing only HMAC reference hashes.
- Added callback URL, secret, rotate button and three-step setup instructions.
- Added plain-language confirmation and conversion explanations.
- Reorganized settings into five simple sections.
- Moved CSS selectors into a collapsed technical block.
- Added Latin `UA` menu mark.
- Existing aggregate statistics and historical data remain intact.

## 1.1.2-dev

- Added payment/copy event tracking and removed the duplicate Suite tab.
