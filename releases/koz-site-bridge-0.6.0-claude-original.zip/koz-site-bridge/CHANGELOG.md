# Changelog

## 0.6.0
- Multiple API keys (`kozbridge_keys`) with label, scopes (basic, content, audit, logs, error_log), last-used day and optional expiry. The pre-0.6.0 key is listed as "Legacy key" with every scope.
- Per-route scope check in `KOZBRIDGE_Auth::permission()`; missing scope returns 403 `kozbridge_scope`.
- Admin "Try it" console via admin-ajax (`manage_options` + nonce) using `KOZBRIDGE_Bridge::run()`.
- Abilities API (WordPress 6.9+): `kozbridge/site-overview`, `kozbridge/diagnostics`, `kozbridge/page-audit`, `kozbridge/sitemap-audit`, `kozbridge/404-log`, `kozbridge/plugins`; `manage_options` only, read-only annotations, optional.
- `/404-log` uses `ramirkz\koz404\KOZ404_Log::query()`; falls back to the legacy option.
- Sitemap roots: `/wp-sitemap.xml` plus same-site `Sitemap:` lines in robots.txt; up to 3000 URLs; `sources` and `languages` counts.
- New endpoints `/security-headers`, `/performance`, `/consent-check`; more response headers in probes.
- `/suite` adds `status` from KOZ plugin public status contracts.
- OpenAPI response schemas `IssuesResponse`, `Log404Response`, `SitemapResponse`, and a 403 response.
- Site Health test `kozbridge_keys` and debug information.
- New classes `KOZBRIDGE_Auth`, `KOZBRIDGE_Admin`, `KOZBRIDGE_Abilities`, `KOZBRIDGE_Site_Health`.
- Support panel without PayPal; updated BTC and USDT addresses.

## 0.5.7
- Removed automatic deactivation of the legacy UA FREE Site Bridge plugin; administrators retain activation control.
- Replaced the generic public OpenAPI permission callback with an explicit schema-only permission callback.
- Documented that X-KOZ-Key is local API authentication, does not control feature availability, and that the hourly throttle is security/abuse protection.
- All diagnostic data endpoints remain authenticated.

## 0.5.6
- Updated WordPress compatibility metadata for WordPress 7.1.
- No functional or API behavior changes.

## 0.5.5
- Replaced direct PHP `fopen` / `fclose` log access with the WordPress Filesystem API.
- Preserved the fixed-path read-only error-log diagnostic and privacy redaction.
- No API-key, route, or existing diagnostic behavior changes.

## 0.5.4
- Added authenticated read-only admin error-log diagnostics.
- Reads only fixed local WordPress/PHP log candidates; no caller-supplied filesystem paths.
- Redacts credentials, cookies, email addresses and local filesystem prefixes before returning recent lines.
- Preserved all existing endpoints and API-key compatibility.

## 0.5.3

- Added safe rendered-page audit for public same-site frontend paths.
- Added sitemap inventory and batched sitemap audit with concrete per-URL issues.
- Added rendered SEO signals: title, description, canonical, robots, hreflang, headings, image alt state, link counts, schema types and document language.
- Expanded HTTP probes from a fixed system allowlist to safe public frontend routes while continuing to block WordPress admin, REST, login, executable and private system paths.
- Added non-DOM HTML parsing fallback for hosts without the PHP DOM extension.
- Preserved read-only operation, existing API keys, rate limits and legacy API compatibility.

## 0.5.2

- Fixed admin submenu registration under the dynamically detected KOZ Suite parent.
- Preserved the existing `admin.php?page=koz-site-bridge` settings URL.
- Removed the duplicate Site Bridge suite-catalog entry.

## 0.5.1

- WordPress.org strict prefix re-audit: canonical `kozbridge / KOZBRIDGE` identifiers.
- Existing API-key settings migrate automatically from historical option names; old values are not deleted during upgrade.
- Added canonical `kozbridge/v1` REST routes while preserving `koz-site-bridge/v1` and `uafree-bridge/v1` compatibility.
- Plugin-specific runtime, suite fallback, admin assets, nonces, error identifiers and support UI identifiers.
- Preserved the read-only, privacy-safe and same-origin safety contracts.

## 0.5.0

- Rebranded as KOZ Site Bridge.
- Added KOZ Suite integration and multilingual administration.
- Added canonical `koz-site-bridge/v1` REST routes and `X-KOZ-Key` authentication.
- Preserved legacy API keys, `uafree-bridge/v1` routes and `X-UAFree-Key` during migration.
- Replaced site-specific safe-probe paths with a generic allowlist.
- Added enqueued admin CSS/JavaScript and the shared KOZ support panel.
- Preserved the read-only, privacy-safe and same-origin safety contracts.
